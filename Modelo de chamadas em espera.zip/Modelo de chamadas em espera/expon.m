% exponential number generation
function r=expon(avg, N)

	r=-avg * log(rand(1,N));
end
